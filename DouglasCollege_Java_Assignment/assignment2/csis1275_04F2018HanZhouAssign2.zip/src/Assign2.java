
public class Assign2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		CalPayroll myPay = new CalPayroll();
		myPay.acceptPay();//main title
		
		
		
	}

}
